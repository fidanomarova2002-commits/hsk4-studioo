HSK 4 Studio — 15 AZN / 60 gün

1–2-ci bölmələr pulsuz, 3–8-ci bölmələr giriş kodu ilə açılır.
Ödəniş WhatsApp 0503841724 üzərindən əl ilə təsdiqlənir.
Müəllim /admin səhifəsində ADMIN_PASSWORD ilə şagird üçün fərdi kod yaradır.
Kod yaradıldığı andan 60 gün etibarlıdır; bitdikdə avtomatik bloklanır.
222 kimi qısa kodlar asan təxmin edilir, buna görə minimum 6 rəqəm tələb olunur.

Server qurulması: pip install -r requirements.txt; SECRET_KEY və ADMIN_PASSWORD mühit dəyişənlərini təyin edin; gunicorn app:app ilə başladın.
DB_PATH mütləq davamlı (persistent) diskdə yerləşməlidir; /tmp verilənləri hostinq yenidən başladıqda itə bilər.
Bu ZIP özü internet linki deyil: server hostinqində yerləşdirilməlidir.
