import os, sqlite3, secrets, hashlib, hmac, json
from pathlib import Path
from datetime import datetime, timedelta, timezone
from flask import Flask, request, jsonify, render_template, session

app=Flask(__name__)
app.secret_key=os.environ.get('SECRET_KEY',secrets.token_hex(32))
DB=os.environ.get('DB_PATH','/tmp/hsk4.sqlite3')
ADMIN=os.environ.get('ADMIN_PASSWORD','')

def conn():
    c=sqlite3.connect(DB);c.row_factory=sqlite3.Row
    c.execute('CREATE TABLE IF NOT EXISTS codes (hash TEXT PRIMARY KEY, label TEXT NOT NULL, expires TEXT NOT NULL, created TEXT NOT NULL, revoked INTEGER DEFAULT 0)')
    c.commit();return c

def hashed(code):return hashlib.sha256(code.strip().upper().encode()).hexdigest()
def valid(code):
    if not code:return False
    with conn() as c:
        r=c.execute('SELECT expires,revoked FROM codes WHERE hash=?',(hashed(code),)).fetchone()
    return bool(r and not r['revoked'] and datetime.fromisoformat(r['expires'])>datetime.now(timezone.utc))

@app.get('/')
def home():return render_template('index.html')
@app.get('/api/status')
def status():return jsonify(active=valid(session.get('code')))
@app.post('/api/login')
def login():
    code=(request.get_json(silent=True) or {}).get('code','')
    if not valid(code):return jsonify(error='Kod yanlışdır və ya müddəti bitib.'),403
    session['code']=code.strip().upper();return jsonify(ok=True)
@app.post('/api/logout')
def logout():session.clear();return jsonify(ok=True)
@app.get('/api/content/<int:i>')
def content(i):
    if i<0 or i>=8:return jsonify(error='Bölmə tapılmadı'),404
    if i>=2 and not valid(session.get('code')):return jsonify(error='Premium giriş tələb olunur'),403
    lessons=json.loads((Path(__file__).parent/'lessons.json').read_text())
    return jsonify(lessons[i])

@app.get('/api/lesson/<int:i>')
def lesson(i):
    if i<0 or i>=8:return jsonify(error='Bölmə tapılmadı'),404
    if i>=2 and not valid(session.get('code')):return jsonify(error='Premium giriş tələb olunur'),403
    return jsonify(index=i)

def admin_ok():
    provided=request.headers.get('X-Admin-Password','')
    return bool(ADMIN and hmac.compare_digest(provided,ADMIN))
@app.post('/api/admin/create')
def create():
    if not admin_ok():return jsonify(error='İcazə yoxdur'),403
    data=request.get_json(silent=True) or {};label=str(data.get('label','Şagird')).strip()[:100]
    code=str(data.get('code','')).strip().upper()
    if not code:
        code='HSK4-'+secrets.token_hex(6).upper()
    if len(code)<3 or len(code)>32 or not all(ch.isascii() and (ch.isalnum() or ch=='-') for ch in code):
        return jsonify(error='Kod 3–32 simvol olmalı, yalnız latın hərfləri, rəqəmlər və - istifadə edilməlidir.'),400
    if code.isdigit() and len(code)<6:
        return jsonify(error='Təhlükəsizlik üçün ən azı 6 rəqəmli kod seçin (məsələn 222847).'),400
    now=datetime.now(timezone.utc);expires=now+timedelta(days=60)
    try:
        with conn() as c:c.execute('INSERT INTO codes (hash,label,expires,created) VALUES (?,?,?,?)',(hashed(code),label,expires.isoformat(),now.isoformat()))
    except sqlite3.IntegrityError:
        return jsonify(error='Bu kod artıq mövcuddur. Başqa kod seçin.'),409
    return jsonify(code=code,label=label,expires=expires.isoformat())
@app.get('/api/admin/list')
def listing():
    if not admin_ok():return jsonify(error='İcazə yoxdur'),403
    with conn() as c:rows=c.execute('SELECT hash,label,expires,revoked FROM codes ORDER BY created DESC').fetchall()
    return jsonify(codes=[dict(r) for r in rows])
@app.post('/api/admin/revoke')
def revoke():
    if not admin_ok():return jsonify(error='İcazə yoxdur'),403
    key=(request.get_json(silent=True) or {}).get('hash','')
    with conn() as c:c.execute('UPDATE codes SET revoked=1 WHERE hash=?',(key,))
    return jsonify(ok=True)
@app.get('/admin')
def admin_page():return render_template('admin.html')
if __name__=='__main__':app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)))
